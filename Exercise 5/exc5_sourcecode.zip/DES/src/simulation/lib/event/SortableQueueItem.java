package simulation.lib.event;

/**
 * Item for the sortable queue
 */
public abstract class SortableQueueItem implements Comparable<SortableQueueItem>{
}